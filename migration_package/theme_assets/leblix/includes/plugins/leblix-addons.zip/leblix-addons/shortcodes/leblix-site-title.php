<?php
// [leblix-site-title]
if( !function_exists('creativesplanet_leblix_sc_site_title') ){
function creativesplanet_leblix_sc_site_title( $atts, $content=NULL ){
	return get_bloginfo('name');
}
}
add_shortcode( 'leblix-site-title', 'creativesplanet_leblix_sc_site_title' );