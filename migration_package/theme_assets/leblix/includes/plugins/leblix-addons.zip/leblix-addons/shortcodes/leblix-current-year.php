<?php
// [leblix-current-year]
if( !function_exists('creativesplanet_leblix_sc_current_year') ){
function creativesplanet_leblix_sc_current_year( $atts, $content=NULL ){
	return date("Y");
}
}
add_shortcode( 'leblix-current-year', 'creativesplanet_leblix_sc_current_year' );