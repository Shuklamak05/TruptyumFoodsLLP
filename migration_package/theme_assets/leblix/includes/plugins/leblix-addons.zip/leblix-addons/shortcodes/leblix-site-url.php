<?php
// [leblix-site-url]
if( !function_exists('creativesplanet_leblix_sc_site_url') ){
function creativesplanet_leblix_sc_site_url( $atts, $content=NULL ){
	return site_url();
}
}
add_shortcode( 'leblix-site-url', 'creativesplanet_leblix_sc_site_url' );