<?php
// [leblix-site-tagline]
if( !function_exists('creativesplanet_leblix_sc_site_tagline') ){
function creativesplanet_leblix_sc_site_tagline( $atts, $content=NULL ){
	return get_bloginfo('description');
}
}
add_shortcode( 'leblix-site-tagline', 'creativesplanet_leblix_sc_site_tagline' );